LaserCube WiFi - outside shape (STEP) - APPROXIMATE

What this is
- The outside shape of the LaserCube WiFi: housing, beam block, front window, the WiFi
  antenna (removable, shown upright), and the connectors, switches and eye bolt where they
  show on the back. Nothing inside the cube is included.
- For designing mounts, cases, rigs and enclosures.
- File: LaserCube-WiFi-outside-approximate.step (STEP AP214), one assembly with named parts.

Units and position
- Millimetres.
- Z points up. The front (laser aperture) faces -Y. X points to the right, seen from the front.
- Origin (0, 0, 0): centre of the bottom of the housing.

Main sizes
- Housing: 100 x 100 mm, 118.75 mm tall (without feet; the feet are not in the model).
- With the antenna upright: 139.7 mm tall.

What is approximate
- Made from the 3D display model on our website, not from engineering drawings. All
  surfaces are flat facets (round parts are faceted), and some small connector parts are
  surfaces only. Accuracy unknown.
- Scaled so the housing is 100 x 100 mm, the published size.
- Tripod thread (1/4"-20): shown only as a 5 mm hole under the cube at X 0, Y +5 (thread
  not drawn); position as in the display model.
- No feet in the model (the published height is 12.5 cm).

Check anything critical against your own cube.
