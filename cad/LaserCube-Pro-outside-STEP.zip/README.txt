LaserCube Pro - outside shape (STEP)

What this is
- The outside shape of the LaserCube Pro: housing, mounting bracket (handle), bracket
  lock knobs, rubber feet, beam block, and the connectors, switches and screen where they
  show on the back. Nothing inside the cube is included.
- For designing mounts, cases, rigs and enclosures.
- File: LaserCube-Pro-outside.step (STEP AP214), one assembly with named parts.

Units and position
- Millimetres.
- Z points up. The front (laser aperture) faces -Y. X points to the right, seen from the front.
- Origin (0, 0, 0): centre of the bottom of the housing. The feet stand below it (down to Z -10).
- The bracket is shown upright.

Main sizes
- Housing: 130 x 130 mm, 128 mm tall; 138 mm tall standing on its feet.
- With the bracket upright and the lock knobs: 186 mm wide and 195.5 mm tall.

Not shown
- The safety eye bolt and the WiFi antenna (their holes are shown), the safety key and
  the cap of the menu knob.

Made from our design files. Check anything critical against your own cube.
