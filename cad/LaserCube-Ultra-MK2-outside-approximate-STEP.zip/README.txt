LaserCube Ultra MK2 - outside shape (STEP) - APPROXIMATE

What this is
- The outside shape of the LaserCube Ultra MK2: housing, mounting bracket, bracket lock
  knobs, rubber feet, beam block, front window, and the connectors, switches, knob and
  screen window where they show on the back. Nothing inside the cube is included.
- For designing mounts, cases, rigs and enclosures.
- File: LaserCube-Ultra-MK2-outside-approximate.step (STEP AP214), one assembly with named parts.

Units and position
- Millimetres.
- Z points up. The front (laser aperture) faces -Y. X points to the right, seen from the front.
- Origin (0, 0, 0): centre of the bottom of the housing. The feet stand below it (down to Z -10).
- The bracket is shown upright.

Main sizes
- Housing: 155 x 155 mm, 143.5 mm tall; 153.5 mm tall standing on its feet.
- With the bracket upright and the lock knobs: 201 mm wide and 196 mm tall.
- The safety key sticks out 25 mm at the back.

What is approximate
- The main body and the back panel (all connector positions) are from the Ultra MK2 design.
- The lid, lower body, bottom plate, feet and tripod thread are taken from the earlier
  150 mm Ultra and stretched to 155 mm: things near the edges can be up to about 2.5 mm off.
- Tripod thread: shown as a 5.2 mm hole (thread not drawn) at X 0, Y -25.8 under the cube,
  from the earlier Ultra; not checked on an Ultra MK2.
- The front aperture, front window and beam block are placed as on the earlier Ultra.
- The bracket is the earlier Ultra bracket, widened to fit. The current bracket's length
  and its holes and slots may differ. The lock knobs are drawn as wing screws.
- The DMX sockets are drawn as 5-pin XLR; the panel holes are the same size as for 3-pin.
- Not shown: the WiFi antenna (its hole is shown).

Check anything critical against your own cube.
